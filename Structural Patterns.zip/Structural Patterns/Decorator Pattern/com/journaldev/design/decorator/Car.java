package com.journaldev.design.decorator;

public interface Car {

	public void assemble();
}