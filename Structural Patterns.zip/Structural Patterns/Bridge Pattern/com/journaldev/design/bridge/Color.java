package com.journaldev.design.bridge;

public interface Color {

	public void applyColor();
}